$(document).ready(function(){
	//Video Background
	$(".player").mb_YTPlayer();
});