$(document).ready(function(){
	//Home Image Slider
	$.backstretch([
	  "images/bg/1.jpg",
	  "images/bg/2.jpg",
	  "images/bg/3.jpg"    
	], {duration: 4500, fade: 'slow'});
	
});